class theme {
  public static sidebar = {
    backgroundColor: '#eceff1',
    expandedBackgroundColor: '#eceff1',
    width: 57,
    expandedWidth: 350,
    menuItemWidth: 42,
    menuItemHeight: 42,
    menuItemColor: '#748b98',
    menuIconSize: 20,
    menuItemSpace: 15
  };

  public static text = {
    small: 9
  };

  public static divider = {
    backgroundColor: '#748b98'
  };
}

export { theme };
