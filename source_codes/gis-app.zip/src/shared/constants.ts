export const ION_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI4ZmVmOGRhZC01ZDBhLTQxNjctYjA3MS0xMjczNjM2ZjlkYTAiLCJpZCI6MTE4NTUwLCJpYXQiOjE2NzExODIzODN9.-iQw8adQDIuLoppgNxsLqWORiy5luoQi3DOZsPjVTrw';

export const rasterUrl =
  'https://ac-tile-server-dev.aereo.co.in/ortho/{z}/{x}/{y}.png?key=rb-iterations-dev/orthomosaic/d4ca6a08-79c0-4d45-872e-9979cbe24bed_cog.tif';

export const terrainURL =
  'https://ac-tile-server-dev.aereo.co.in/terrain/?iteration_id=d4ca6a08-79c0-4d45-872e-9979cbe24bed&key=rb-iterations-dev/terrain_tiles/d4ca6a08-79c0-4d45-872e-9979cbe24bed_tt';

export const mvtURL =
  'https://ac-tile-server-dev.aereo.co.in/vector/{z}/{x}/{y}.pbf?key=rb-iterations-dev/vector_tiles/c39f14c6-69fa-4584-83b1-a475de8f7f5a';

export const glyphsURL =
  'https://cdn.rawgit.com/klokantech/mapbox-gl-js-offline-example/v1.0/font/{fontstack}/{range}.pbf';

export const viewBound: [number, number, number, number] = [
  87.01091189016857, 23.802298682242647, 87.02987852815343, 23.817440580860772
];
export const viewPoint = ['87.0180062252', '23.8108504077'];
export const minZoom = 14;
export const maxZoom = 19;
export const mvtMinZoom = 10;
export const mvtMaxZoom = 22;

export const ORG_TOKEN = '53367d64b91df4dfa1a5960e641471c83e29974f48a32b7f6c';
