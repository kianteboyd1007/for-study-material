import { Viewer } from 'cesium';
import { CesiumLayerTool } from '../tools/layers/cesium-layer-tool';
import {
  FeatureInfoTool,
  DrawingTools,
  SelectTools,
  StyleFeatureTool,
  TextTool,
} from '../tools';
import { MapTool, MapTools } from '../tools/base';
import CanvasEventHandler from '../shared/canvas-event-handler';

export type CesiumViewerType = Viewer & {
  _mapTool: MapTools;
  _canvasEventHandler: CanvasEventHandler;
  setMapTool: (mapTool: MapTool) => boolean;
  deactivateCurrentMapTool: () => void;
  drawingTools: DrawingTools;
  selectTools: SelectTools;
  styleTools: StyleFeatureTool;
  textTool: TextTool;
  layerTool: CesiumLayerTool;
  infoTool: FeatureInfoTool;
};
