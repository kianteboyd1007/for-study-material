import {
  Cartesian2,
  Cartesian3,
  Cartographic,
  Event,
  Ion,
  Math as CesiumMath,
  SceneMode,
  Viewer,
} from 'cesium';

import DrawingToolsMixin from './mixins/drawing-tool.mixin';
import CesiumLayerToolMixin from './mixins/layer-tool.mixin';
import SelectToolsMixin from './mixins/select-tool.mixin';
import StyleToolsMixin from './mixins/style-tool.mixin';
import TextDrawToolsMixin from './mixins/text-tool.mixin';
import { CesiumViewerType } from './types';
import { GeometryIDType, GEOMETRY_TYPE, WKT } from './utils';
import { GeoJson } from './utils/geojson';
import CesiumInfoToolMixin from './mixins/feature-info-tool.mixin';
import { GLOBE_RADIUS, ShortCutResponseTime } from './shared';

export class CesiumViewer {
  private _viewer: CesiumViewerType | undefined;
  destroyingCesiumViewer = false;

  // Camera option
  private _lat = 0;
  private _lon = 0;
  private _heading = 0;
  private _pitch = 0;
  private _roll = 0;
  private _height = 0;
  private _disableZoom = false;
  readonly eventCesiumViewerCreated = new Event();

  readonly eventCesiumViewerDestroyed = new Event();

  constructor(
    cesiumContainer: Element,
    token: string,
    options?: Viewer.ConstructorOptions,
    disableZoom?: boolean,
  ) {
    Ion.defaultAccessToken = token;
    this._viewer = new Viewer(cesiumContainer, options) as CesiumViewerType;

    this.initMixins();

    this.eventCesiumViewerCreated.raiseEvent();

    if (disableZoom) {
      this._disableZoom = true;
      const scene = this._viewer.scene;
      scene.screenSpaceCameraController.enableZoom = false;
    }

    this._viewer.scene.screenSpaceCameraController.maximumZoomDistance =
      GLOBE_RADIUS * 3;
    // To prevent that camera goes under terrain.
    this._viewer.scene.screenSpaceCameraController.enableCollisionDetection =
      true;

    // Adjust camera's height by globe diamiter.
    const ellipsoid = this._viewer.scene.globe.ellipsoid;
    const camera = this._viewer.scene.camera;
    const cameraHeight = ellipsoid.cartesianToCartographic(
      camera.position,
    ).height;

    if (cameraHeight > GLOBE_RADIUS * 3) {
      camera.moveForward(cameraHeight - GLOBE_RADIUS * 3);
    }
  }

  private initMixins() {
    const viewer = this._viewer;

    viewer?.extend(DrawingToolsMixin);
    viewer?.extend(SelectToolsMixin);
    viewer?.extend(StyleToolsMixin);
    viewer?.extend(TextDrawToolsMixin);
    viewer?.extend(CesiumLayerToolMixin);
    viewer?.extend(CesiumInfoToolMixin);
  }

  get viewer() {
    return this._viewer;
  }

  get disableZoom() {
    return this._disableZoom;
  }

  zoomWithCtrl(forward: boolean) {
    if (!this._viewer) {
      return;
    }
    const scene = this._viewer.scene;
    const camera = this._viewer.camera;
    const ellipsoid = scene.globe.ellipsoid;
    const cameraHeight = ellipsoid.cartesianToCartographic(
      camera.position,
    ).height;
    const moveRate = cameraHeight / 10.0;

    if (forward) {
      camera.moveForward(moveRate);
    } else {
      camera.moveBackward(moveRate);
    }
  }

  flyTo = (
    longitude: string,
    latitude: string,
    height = 9000,
    heading = 0.0,
    pitch = -CesiumMath.PI_OVER_TWO,
    roll = 0.0,
  ) => {
    if (this._viewer) {
      this._lon = parseFloat(longitude);
      this._lat = parseFloat(latitude);
      this._height = height;
      this._heading = heading;
      this._pitch = pitch;
      this._roll = roll;

      this._viewer.camera.flyTo({
        destination: Cartesian3.fromDegrees(this._lon, this._lat, this._height),
        orientation: {
          heading: this._heading,
          pitch: this._pitch,
          roll: this._roll,
        },
        duration: 2,
      });
    }
  };

  switchTo2D() {
    if (!this._viewer) {
      return;
    }

    const viewer = this._viewer;
    const scene = viewer.scene;

    if (scene.mode === SceneMode.SCENE2D) {
      return;
    }
    const camera = viewer.camera;
    const canvas = viewer.scene.canvas;
    const screenCenter = new Cartesian2(
      canvas.clientWidth / 2.0,
      canvas.clientHeight / 2.0,
    );
    const ellipsoid = viewer.scene.globe.ellipsoid;
    const origin = camera.pickEllipsoid(screenCenter, ellipsoid);

    if (!origin) {
      return;
    }
    const originCarto = Cartographic.fromCartesian(origin);
    const cameraCarto = Cartographic.fromCartesian(camera.position);

    camera.flyTo({
      destination: Cartesian3.fromRadians(
        originCarto.longitude,
        originCarto.latitude,
        cameraCarto.height,
      ),
      orientation: {
        heading: 0,
        pitch: -CesiumMath.PI_OVER_TWO,
        roll: 0,
      },
      duration: 0,
      complete: () => {
        scene.mode = SceneMode.SCENE2D;
      },
    });
  }

  switchTo3D() {
    if (!this._viewer) {
      return;
    }
    const scene = this._viewer.scene;
    if (scene.mode === SceneMode.SCENE3D) {
      return;
    }

    scene.mode = SceneMode.SCENE3D;
  }

  exportToWKT() {
    if (!this._viewer) {
      return;
    }
    return WKT.toWKT(this._viewer);
  }

  importWKT(
    wktString: string,
    geometryId?: string,
    geometryLabel?: string,
  ): GeometryIDType | undefined {
    if (!this._viewer) {
      return;
    }
    const geometryIds = WKT.fromWKT(
      wktString,
      this._viewer,
      geometryId,
      geometryLabel,
    );
    return geometryIds;
  }

  exportToGeoJson() {
    if (!this._viewer) {
      return;
    }
    return GeoJson.toGeoJson(this._viewer);
  }

  importGeoJson(geoJsonText: string): GeometryIDType | undefined {
    if (!this._viewer) {
      return;
    }
    const geometryIds = GeoJson.fromGeoJson(geoJsonText, this._viewer);
    return geometryIds;
  }

  exportGeometryToGeoJson(id: string, geometryType: string) {
    if (!this._viewer) {
      return;
    }

    switch (geometryType) {
      case GEOMETRY_TYPE.POINT:
        return GeoJson.exportPoint(this._viewer, id);
      case GEOMETRY_TYPE.LINE:
        return GeoJson.exportLine(this._viewer, id);
      case GEOMETRY_TYPE.POLYGON:
        return GeoJson.exportPolygon(this._viewer, id);
      default:
        return;
    }
  }

  setShortcutResponseTime(responseTime: ShortCutResponseTime) {
    if (!this._viewer) {
      return;
    }
    this._viewer._canvasEventHandler.responseTime = responseTime;
  }
  // Destroy cesium viewer
  private destroyCesiumViewer() {
    const cesiumViewer = this._viewer;
    cesiumViewer?.destroy();
    this.eventCesiumViewerDestroyed.raiseEvent();
    this._viewer = undefined;
  }
}
