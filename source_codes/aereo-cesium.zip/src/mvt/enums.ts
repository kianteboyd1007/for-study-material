export enum FocusedLayerId {
  Point = 'selected-point-feature',
  Line = 'selected-line-feature',
  Polygon = 'selected-polygon-feature',
}
