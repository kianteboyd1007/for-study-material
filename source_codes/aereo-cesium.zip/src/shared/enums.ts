export enum MouseButton {
  LeftButton = 1,
  RightButton = 2,
  MidButton = 4,
}
// Camera move direction
export enum CAMERA_MOVE_DIRECTION {
  None = '',
  MoveForward = 'moveForward',
  MoveBackward = 'moveBackward',
  MoveUp = 'moveUp',
  MoveDown = 'moveDown',
  MoveLeft = 'moveLeft',
  MoveRight = 'moveRight',
  MoveUpLeft = 'moveUpLeft',
  MoveUpRight = 'moveUpRight',
  MoveUpForward = 'moveUpForward',
  MoveUpBackward = 'moveUpBackward',
  MoveDownLeft = 'moveDownLeft',
  MoveDownRight = 'moveDownRight',
  MoveDownForward = 'moveDownForward',
  MoveDownBackward = 'moveDownBackward',
  MoveLeftForward = 'moveLeftForward',
  MoveLeftBackward = 'moveLeftBackward',
  MoveRightForward = 'moveRightForward',
  MoveRightBackward = 'moveRightBackward',
}
// Camera rotate direction
export enum CAMERA_ROTATE_DIRECTION {
  None = '',
  RotateRight = 'rotateRight',
  RotateLeft = 'rotateLeft',
  RotateUp = 'rotateUp',
  RotateDown = 'rotateDown',
}
