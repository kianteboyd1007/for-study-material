import { Cartesian2, Color } from 'cesium';
import { CAMERA_MOVE_DIRECTION } from './enums';

export const DEFAULT_POLYGON_OPACITY = 0.2;
export const DEFAULT_POLYGON_COLOR = Color.WHITE.withAlpha(
  DEFAULT_POLYGON_OPACITY,
);
export const SELECTED_LINE_PRIMITIVE_COLOR = Color.YELLOW.withAlpha(0.5);
export const POLYLINE_MINIMUM_PIXEL_SIZE = 20;
export const MAIN_VERTICES_MINIMUM_PIXEL_SIZE = 20;
export const POLYGON_MINIMUM_PIXEL_SIZE = 20;

export const POINT_LABEL_OFFSET = new Cartesian2(0, -28);

export const SELECTED_POLYGON_PRIMITIVE_COLOR = Color.YELLOW.withAlpha(0.5);

export const SNAP_PIXEL_SIZE_TO_VERTEX = 15;
export const SNAP_PIXEL_SIZE_TO_EDGE = 10;
export const MIN_POLYGON_VERTEX_NUM = 3;
export const MIN_LINE_VERTEX_NUM = 2;

export const DEFAULT_LABEL_PIXEL_OFFSET = new Cartesian2(0, -9);
export const MOUSE_DELTA = 10;
export const ESC_KEY = 'Escape';

export const EPS = 1e-6;

// Zoom level and bounding box calculation :
// In 3D mode, we couldn't specify zoom level exactly,
// but can estimate by using the camera distance from the target.
// zoomlevel = (max_distance_from_target - distance_from_target) / max_distance_from_target * max_zoom_level.
// We assumed the following:
// zoomlevel = 1 if max_distance_from_target > 1e4 meters.
// zoomlevel = max_zoom_level if distance_from_target < 125 meters.
// zoomlevel value will be linearly decreasing in the interval [125, 1e4] meters of camera distance.
export const MAX_ZOOM_LEVEL = 16;
export const MAX_CAMERA_DISTANCE = 1e4;
export const EPS_ZOOM_LEVEL = 0.2;
export const GLOBE_RADIUS = 6378137;
// Coordinate system used in Google Earth and GSP systems.
// It represents Earth as a three-dimensional ellipsoid.
export const EPSG4326 = 4326;
// Shortcut key response time
export const MIN_RESPONSE_TIME = 10;
export const SHORTCUT_COMBINATION = [
  CAMERA_MOVE_DIRECTION.MoveUpLeft,
  CAMERA_MOVE_DIRECTION.MoveUpRight,
  CAMERA_MOVE_DIRECTION.MoveDownLeft,
  CAMERA_MOVE_DIRECTION.MoveDownRight,
  CAMERA_MOVE_DIRECTION.MoveUpForward,
  CAMERA_MOVE_DIRECTION.MoveUpBackward,
  CAMERA_MOVE_DIRECTION.MoveDownForward,
  CAMERA_MOVE_DIRECTION.MoveDownBackward,
  CAMERA_MOVE_DIRECTION.MoveLeftForward,
  CAMERA_MOVE_DIRECTION.MoveLeftBackward,
  CAMERA_MOVE_DIRECTION.MoveRightForward,
  CAMERA_MOVE_DIRECTION.MoveRightBackward,
];
