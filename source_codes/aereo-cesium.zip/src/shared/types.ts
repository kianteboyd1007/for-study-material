export type ShortCutResponseTime = {
  PanningResponseTime: number;
  HRotatingResponseTime: number;
  VRotatingResponseTime: number;
  ZoomingResponseTime: number;
};
