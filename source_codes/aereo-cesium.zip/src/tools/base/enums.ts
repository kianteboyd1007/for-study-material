export enum SelectMode {
  None = 0,
  Select = 1,
  Edit = 2,
  Info = 3,
}
