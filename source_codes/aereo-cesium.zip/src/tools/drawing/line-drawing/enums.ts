export const enum SnapMode {
  NONE = -1,
  VERTEX = 0,
  EDGE = 1,
}
