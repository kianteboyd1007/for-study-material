export enum DrawingMode {
  None = -1,
  BeforeDraw = 0,
  Drawing = 1,
  AfterDraw = 2,
  EditDraw = 3,
}
