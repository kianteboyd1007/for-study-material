import { Viewer } from 'cesium';
import { LineDrawingTools, PointDrawingTools, PolygonDrawingTools } from '..';
import { CesiumViewerType } from '../../types';

export * from './polygon-drawing/drawing-tools';
export * from './line-drawing/drawing-tools';
export * from './point-drawing/drawing-tools';
export * from './drawing-tool-settings';
export * from './enums';
export * from './types';

export class DrawingTools {
  polygonDrawingTools: PolygonDrawingTools;
  lineDrawingTools: LineDrawingTools;
  pointDrawingTools: PointDrawingTools;

  constructor(viewer: Viewer) {
    this.polygonDrawingTools = new PolygonDrawingTools({
      viewer: <CesiumViewerType>viewer,
    });
    this.lineDrawingTools = new LineDrawingTools({
      viewer: <CesiumViewerType>viewer,
    });
    this.pointDrawingTools = new PointDrawingTools({
      viewer: <CesiumViewerType>viewer,
    });
  }

  destroy() {
    if (this.polygonDrawingTools) {
      this.polygonDrawingTools.destroy();
    }
    if (this.lineDrawingTools) {
      this.lineDrawingTools.destroy();
    }
    if (this.pointDrawingTools) {
      this.pointDrawingTools.destroy();
    }
  }
}
