import { FeatureInfoTool } from './feature-info-tool';

export { FeatureInfoTool };
