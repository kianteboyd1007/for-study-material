import { MapToolConstructorOptions } from '../base';

/**
 * Options for info tool
 */
export interface FeatureInfoConstructorOptions
  extends MapToolConstructorOptions {
  properties?: Record<string, any>;
}
