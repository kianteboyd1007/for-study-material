import {
  Cartesian3,
  Cartographic,
  Math as CesiumMath,
  // @ts-ignore
  VERSION,
} from 'cesium';

export function radianToString(x: number) {
  return CesiumMath.toDegrees(x).toString();
}

export function capitalizeFirstLetter(x: string) {
  return x.charAt(0).toUpperCase() + x.slice(1);
}

export function convertTypeToTitleCase(type: string) {
  let standardType = type.toLowerCase();
  standardType = standardType.replace('multi', 'Multi');
  standardType = standardType.replace('polygon', 'Polygon');
  standardType = standardType.replace('line', 'Line');
  standardType = standardType.replace('string', 'String');
  standardType = standardType.replace('point', 'Point');

  return standardType;
}

export function isIncludeProperty(
  parent: Record<string, any>,
  child: Record<string, any>,
) {
  for (const key in child) {
    if (!parent[key]) {
      return false;
    }
    if (parent[key] !== child[key]) {
      return false;
    }
  }
  return true;
}

export function checkCesiumVersion() {
  const cesiumVersion = `@aus-platform/cesium is using Cesium version ${VERSION}`;
  return cesiumVersion;
}

export function convertToCartographicArray(positions: Cartesian3[]) {
  const cartoGraphicPositions = positions.map((position) => {
    const cartographic = Cartographic.fromCartesian(position);
    return new Cartographic(
      CesiumMath.toDegrees(cartographic.longitude),
      CesiumMath.toDegrees(cartographic.latitude),
    );
  });
  return cartoGraphicPositions;
}

export function convertToCartesianArray(positions: Cartographic[]) {
  // Without considering height of cartographic position.
  const cartesianPositions = positions.map((position) =>
    Cartesian3.fromDegrees(position.longitude, position.latitude),
  );
  return cartesianPositions;
}
